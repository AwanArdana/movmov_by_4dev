import 'dart:convert';

import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:movmov/Detail/detail_screen.dart';
import 'package:movmov/constants.dart';


class RecomendsPage extends StatelessWidget{


  const RecomendsPage({
    Key key, this.list,
  }): super(key: key);

  final List list;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          // RecomendCard(
          //   image: "https://drive.google.com/uc?export=view&id=${list[0]['mov_cover_id']}",
          //   title: "${list[0]['mov_title']}",
          //   year: "${list[0]['mov_year']}",
          //   press: (){},
          // ),
          // RecomendCard(
          //   image: "https://drive.google.com/uc?export=view&id=${list[1]['mov_cover_id']}",
          //   title: "${list[1]['mov_title']}",
          //   year: "${list[1]['mov_year']}",
          //   press: (){},
          // ),
          RecomendCard(
            image:"https://awanapp.000webhostapp.com/cover/${list[0]['mov_cover_id']}",
            title: "${list[0]['mov_title']}",
            year: "${list[0]['mov_year']}",
            press: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => DetailScreen(),
                )
              );
            },
          ),
          RecomendCard(
            image:"https://awanapp.000webhostapp.com/cover/${list[1]['mov_cover_id']}",
            title: "${list[1]['mov_title']}",
            year: "${list[1]['mov_year']}",
            press: (){},
          ),
          RecomendCard(
            image:"https://awanapp.000webhostapp.com/cover/${list[2]['mov_cover_id']}",
            title: "${list[2]['mov_title']}",
            year: "${list[2]['mov_year']}",
            press: (){},
          )

          // RecomendCard(
          //   image: "https://drive.google.com/uc?export=view&id=10LnmkYfOvvpyXEt7YAEt9Gmmpw5OKJRH",
          //   title: "OnePiece",
          //   year: "2018",
          //   press: (){},
          // ),
          // RecomendCard(
          //   image: "https://drive.google.com/uc?export=view&id=10LnmkYfOvvpyXEt7YAEt9Gmmpw5OKJRH",
          //   title: "OnePiece",
          //   year: "2018",
          //   press: (){},
          // ),
        ],
      ),
    );
  }

}

class RecomendCard extends StatelessWidget{
  const RecomendCard({
    Key key, this.image, this.title, this.year, this.press, this.list,

  }) : super(key: key);

  final List list;
  final String image, title, year;
  final Function press;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.only(
          left: kDefaultPadding,
          right: kDefaultPadding / 2,
          bottom: kDefaultPadding * 2.5
      ),
      width: size.width * 0.4,
      child: Column(
        children: <Widget>[
          new Image.network(image),
          GestureDetector(
            onTap: press,
            child: Container(
              padding: EdgeInsets.all(kDefaultPadding / 2),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    bottomRight: Radius.circular(10),
                    bottomLeft: Radius.circular(10),
                  ),
                  boxShadow: [
                    BoxShadow(
                      offset: Offset(0, 10),
                      blurRadius: 50,
                      color: kPrimaryColor.withOpacity(0.23),
                    )
                  ]
              ),
              child: Row(
                children: <Widget>[
                  RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: "$title\n".toUpperCase(),
                          style: Theme.of(context).textTheme.button,
                        ),
                        TextSpan(
                            text: "$year".toUpperCase(),
                            style: TextStyle(
                              color: kPrimaryColor.withOpacity(0.5),
                            )
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

}