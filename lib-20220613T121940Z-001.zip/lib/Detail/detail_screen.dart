import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:movmov/Detail/component/bodydetail.dart';

class DetailScreen extends StatelessWidget{
  DetailScreen({Key key, this.Mov_id,}) : super(key: key);

  final String Mov_id;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BodyDetail(Mov_id: Mov_id,),
    );
  }
}